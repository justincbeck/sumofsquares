computefarm

This is the framework distribution of computefarm.

To run a JavaSpaces worker, simple type "run" at a command prompt.
For more details see the javadoc in docs/apidocs/index.html and http://computefarm.jini.org/.
